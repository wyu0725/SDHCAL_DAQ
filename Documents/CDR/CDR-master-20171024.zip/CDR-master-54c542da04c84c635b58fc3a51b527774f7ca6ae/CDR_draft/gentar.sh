
tag=`date  +%Y%m%d_%H%M%S`

tar zcvf CDR_${tag}.tgz main_CDR.tex Style Appendices Chapters main_CDR.pdf makebib.sh makefile ChangeLog 
