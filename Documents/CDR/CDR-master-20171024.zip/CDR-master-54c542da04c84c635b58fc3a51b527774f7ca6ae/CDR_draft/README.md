2017.08.15 Li Gang created the latex frame of CEPC CDR, the structrue is according to Joao's talk at http://indico.ihep.ac.cn/event/7151/
