# CEPC_Hjj2017
The 2017 CEPC note for h->bb, cc,gg 
